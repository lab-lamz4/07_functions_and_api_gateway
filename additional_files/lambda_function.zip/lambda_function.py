import json
from datetime import datetime
def lambda_handler(event, context):
    # TODO implement
    current_datetime = datetime.now()
    return {
        'statusCode': 200,
        'body': json.dumps('Hello from Lambda!'),
        'time': json.dumps(current_datetime, default=str)
    }